<?php 
	require_once "header.php";
	
 ?>
 <header>
      <div class="container">
        <!-- <img class="img-fluid mb-5 d-block mx-auto" src="img/profile.png" alt=""> -->
        <!-- <h1 class="text-uppercase mb-0">Start Bootstrap</h1> -->
        <!-- <hr class="star-light"> -->
       <!--  <h2 class="font-weight-light mb-0">Web Developer - Graphic Artist - User Experience Designer</h2> -->

       <p style="color:red;margin-top:200px;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
       tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
       quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
       consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
       cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
       proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
      </div>
    </header> 

    <?php 
    	require_once "footer.php";
     ?>