<?php 
	require_once "functions.php";
	interface Parameter{
		const HOST = "localhost";
		const USER = "root";
		const PASSWORD = "";
		const DATABASE = "moviezone";
	}
 ?>